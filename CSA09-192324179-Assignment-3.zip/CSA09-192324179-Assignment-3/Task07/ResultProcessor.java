import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/** Task 7 - Concurrent, fault-tolerant semester result processor (ExecutorService + Callable + Future). */
public class ResultProcessor {

    static class CorruptFileException extends Exception {                // checked: validation failure
        CorruptFileException(String m) { super(m); }
    }

    record Outcome(String file, int marks) {}

    /** The Callable: read -> validate -> compute. Throws on any problem; never kills other tasks. */
    static class ScoreTask implements Callable<Outcome> {
        private final Path path;
        ScoreTask(Path p) { this.path = p; }
        @Override public Outcome call() throws IOException, CorruptFileException {
            List<String> lines = Files.readAllLines(path);                // NoSuchFileException if missing
            try { java.util.concurrent.locks.LockSupport.parkNanos(300_000); } catch (Exception ignored) {} // simulate I/O latency
            if (lines.isEmpty()) throw new CorruptFileException("empty file");
            String[] parts = lines.get(0).split(",");
            if (parts.length != 2) throw new CorruptFileException("bad format: " + lines.get(0));
            int score;
            try { score = Integer.parseInt(parts[1].trim()); }
            catch (NumberFormatException e) { throw new CorruptFileException("non-numeric score"); }
            if (score < 0 || score > 100) throw new CorruptFileException("score out of range: " + score);
            return new Outcome(path.getFileName().toString(), score * 1);  // result = marks
        }
    }

    static class Summary {
        final ConcurrentHashMap<String, Integer> successes = new ConcurrentHashMap<>();   // file -> marks
        final ConcurrentHashMap<String, String> failures = new ConcurrentHashMap<>();     // file -> reason
        final AtomicInteger ok = new AtomicInteger(), bad = new AtomicInteger();
    }

    static Summary process(List<Path> files, int poolSize) throws InterruptedException {
        ExecutorService pool = Executors.newFixedThreadPool(poolSize);
        Summary s = new Summary();
        Map<Future<Outcome>, Path> futures = new LinkedHashMap<>();
        for (Path p : files) futures.put(pool.submit(new ScoreTask(p)), p);
        for (Map.Entry<Future<Outcome>, Path> e : futures.entrySet()) {
            String name = e.getValue().getFileName().toString();
            try {
                Outcome o = e.getKey().get();
                s.successes.put(o.file(), o.marks()); s.ok.incrementAndGet();
            } catch (ExecutionException ex) {                               // failure of ONE task only
                Throwable c = ex.getCause();
                String kind = (c instanceof NoSuchFileException) ? "MISSING" : "CORRUPT/IO";
                s.failures.put(name, kind + ": " + c.getMessage()); s.bad.incrementAndGet();
            }
        }
        pool.shutdown();
        return s;
    }

    static List<Path> generate(Path dir, int n) throws IOException {
        List<Path> list = new ArrayList<>();
        Random r = new Random(42);
        for (int i = 0; i < n; i++) {
            Path p = dir.resolve("score" + i + ".txt");
            int roll = r.nextInt(100);
            if (roll < 2) Files.writeString(p, "R" + i + ",abc\n");               // corrupt
            else if (roll < 3) { /* missing: path listed, file not created */ }
            else Files.writeString(p, "R" + i + "," + r.nextInt(101) + "\n");
            list.add(p);
        }
        return list;
    }

    public static void main(String[] args) throws Exception {
        // ---- hand-checkable small set ----
        Path small = Files.createTempDirectory("small");
        List<Path> sf = new ArrayList<>();
        for (int i = 1; i <= 7; i++) { Path p = small.resolve("ok" + i + ".txt"); Files.writeString(p, "R" + i + "," + (i * 10) + "\n"); sf.add(p); }
        Path c1 = small.resolve("bad1.txt"); Files.writeString(c1, "R8,xyz\n"); sf.add(c1);
        Path c2 = small.resolve("bad2.txt"); Files.writeString(c2, "R9,150\n"); sf.add(c2);
        sf.add(small.resolve("missing.txt"));                                  // never created
        Summary s = process(sf, 4);
        System.out.println("Hand-checked set: expected success=7 failed=3");
        System.out.println("Actual          : success=" + s.ok + " failed=" + s.bad + " total=" + (s.ok.get() + s.bad.get()));
        s.failures.forEach((k, v) -> System.out.println("   FAIL " + k + " -> " + v));

        // ---- 10,000 files, pool sizes 1,2,4,8 ----
        Path dir = Files.createTempDirectory("results");
        List<Path> files = generate(dir, 10_000);
        System.out.println("\nPool  Time(ms)  Success  Failed  Total");
        for (int p : new int[]{1, 2, 4, 8}) {
            long t0 = System.nanoTime();
            Summary r = process(files, p);
            long ms = (System.nanoTime() - t0) / 1_000_000;
            System.out.printf("%4d  %8d  %7d  %6d  %5d%n", p, ms, r.ok.get(), r.bad.get(), r.ok.get() + r.bad.get());
        }
    }
}
