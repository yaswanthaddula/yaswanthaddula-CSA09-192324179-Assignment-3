# Task 7 – Program Output

Paste the console output of each program below (and add screenshots to this folder, e.g. `Task07-run1.png`).

## Output of run 1

```
(paste output here)
```

## Output of run 2 / further runs (if required by the question)

```
(paste output here)
```
