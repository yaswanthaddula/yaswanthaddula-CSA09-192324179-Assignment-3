# Task 7 – Design a Concurrent, Fault-Tolerant Processor from First Principles (K5 – Evaluate)

Files: `ResultProcessor.java`, `OUTPUT.md`
Run: `cd Task07 && javac ResultProcessor.java && java ResultProcessor`
The program (1) processes a hand-checkable set of 10 files (expected 7 OK, 3 failed), then (2) generates 10,000 score files (≈2 % corrupt, ≈1 % missing) and processes them with pools of 1, 2, 4 and 8 threads, printing time and counts.

## Stage 1 – Interpret the Problem (Joint)

**Parallel tasks:** every file is independent: read → validate → compute. 10,000 independent tasks (embarrassingly parallel).
**Shared data:** the results (success map), the failure log and the counters; also the list of futures.

**Failures and handling**

| Failure | Exception | Handling |
|---|---|---|
| File missing | `NoSuchFileException` (IOException) | task fails; recorded as MISSING |
| File unreadable | `IOException` | recorded as IO error |
| Empty / wrong format / non-numeric / score out of 0–100 | `CorruptFileException` (custom, checked) | recorded as CORRUPT with reason |
| Task throws unexpected `RuntimeException` | e.g. NPE | caught as `ExecutionException`, recorded |
| Pool never finishes (hung read) | – | use `get(timeout)` / `awaitTermination` (limitation) |

**Measurable requirements**
1. Every one of the 10,000 files is accounted for: `successes + failures = 10,000`.
2. One bad file never stops other files (all good files processed).
3. A failure report lists file name and reason for 100 % of failures.
4. Total time with 8 threads is lower than with 1 thread (target ≥ 2× speed-up in the measurement).
5. Hand-checked set of 10 files gives exactly 7 successes and 3 failures.

## Stage 2 – Design (Student A)

### Class diagram
```
ResultProcessor
 ├─ process(List<Path>, poolSize) : Summary
 ├─ ScoreTask implements Callable<Outcome>
 │      call() throws IOException, CorruptFileException
 ├─ Outcome(record: file, marks)
 ├─ Summary
 │      ConcurrentHashMap<String,Integer> successes
 │      ConcurrentHashMap<String,String>  failures
 │      AtomicInteger ok, bad
 └─ CorruptFileException extends Exception
```

### Pseudocode
```
process(files, p):
    pool = newFixedThreadPool(p)
    for file in files: futures[file] = pool.submit(new ScoreTask(file))
    for each (future, file) in futures:
        try:   outcome = future.get()            # waits for that task
               successes.put(file, marks); ok++
        catch ExecutionException ex:             # exception thrown inside the task
               failures.put(file, classify(ex.getCause())); bad++
    pool.shutdown()
    assert ok + bad == files.size()
    return summary

ScoreTask.call():  lines = readAll(file)  # may throw
                   validate(lines)        # may throw CorruptFileException
                   return Outcome(file, marks)
```

### Choice of concurrent collection (justification)
`ConcurrentHashMap` for results and failures: many threads can insert without a global lock (fine-grained locking/CAS), no `ConcurrentModificationException`, O(1) average put, and keyed by file name so duplicates are impossible. `AtomicInteger` counters are lock-free. A `Collections.synchronizedMap` would serialise all writers; `CopyOnWriteArrayList` would be O(n) per insert (wrong for 10,000 frequent writes). (Alternative: `ConcurrentLinkedQueue` if only an unordered list of failures is needed.)

### Exception handling design
Each task throws instead of swallowing; the exception is stored in its own `Future`. `future.get()` rethrows it wrapped in `ExecutionException` and the collector catches it **per file** – so one failure affects only that file. Nothing escapes to the pool threads, and worker threads continue with the next task.

## Stage 3 – Implement and Measure (Student B)

### Hand-checked set
Expected `success=7 failed=3 total=10`; actual (reference run) matched: `ok1…ok7` succeed, `bad1.txt` (non-numeric), `bad2.txt` (score 150) and `missing.txt` fail.

### Timing (fill from your run; "reference run" shown for shape only)

| Pool size | Time (ms) | Success | Failed | Total |
|---|---|---|---|---|
| 1 | | | | 10,000 |
| 2 | | | | 10,000 |
| 4 | | | | 10,000 |
| 8 | | | | 10,000 |

Reference run: ≈4,500 / 2,100 / 1,000 / 520 ms with 9,715 successes and 285 failures every time (counts are identical for every pool size – the correctness check). Your times will differ with your CPU/disk.

### Unhandled failures
In my runs no failure went unhandled. Record any you find (for example: a task hung, results counted twice, `OutOfMemoryError` with large pools). Failures that this design does not handle: a task that blocks forever, JVM crash before the summary is written.

## Stage 4 – Defend the Design (Joint)

### Recommended pool size and why more threads did not always help
For I/O-bound tasks a pool larger than the number of cores helps because threads wait for the disk; rule of thumb: `threads ≈ cores × (1 + wait/compute)`. In practice I would recommend **about 2 × number of cores (e.g. 8)** and confirm by measurement. Beyond that more threads do not help: the disk/file-system bandwidth becomes the bottleneck, context-switching and scheduling overhead grow, each thread costs stack memory, the single collector loop is sequential (Amdahl's law), and results show diminishing returns (e.g. 4→8 gives less than 2×; 8→64 gives almost nothing or is slower).

### How the design guarantees a complete and correct summary
- Every submitted task has exactly one `Future`; each future is `get()` once, in a `try/catch`, and ends in either `successes` or `failures`.
- Counters and maps are thread-safe, so no lost updates.
- The collector asserts `ok + bad == total`.
- `shutdown()` after all futures are collected ensures no work is left.
- Failures include file name and reason, so the summary is auditable.

### One remaining limitation
No timeout/retry: if a file read hangs (network drive), `future.get()` blocks forever – fix with `get(timeout)` + `cancel(true)`; also, results are only in memory – a JVM crash loses them (write results incrementally to a file/database).

## Alternative Concept and Complexity Analysis

```java
// A. parallel stream
files.parallelStream().forEach(p -> {
    try { successes.put(p.toString(), score(p)); }
    catch (Exception e) { failures.put(p.toString(), e.toString()); }   // MUST catch inside lambda
});
// B. one thread per file
for (Path p : files) new Thread(() -> process(p)).start();     // 10,000 threads
```

| | ExecutorService (p threads) | Parallel stream | One thread per file |
|---|---|---|---|
| Total time (n files, cost t) | ≈ ⌈n/p⌉·t; p tunable | ≈ n·t/(cores) – uses the shared ForkJoin common pool (size = cores − 1); cannot easily tune for I/O-bound work | ideal n·t/cores for CPU, but dominated by creating n threads and context switching; may be slow or crash |
| Memory (threads × stack) | p × ~1 MB (e.g. 8 MB) | (cores−1) × ~1 MB – small | 10,000 × ~1 MB ≈ **10 GB** of stack space reserved → `OutOfMemoryError: unable to create native thread` |
| Failure in one file | Captured in its `Future` (`ExecutionException`) – easy, per-file | An uncaught exception in the lambda aborts/propagates from the whole terminal operation; you must catch inside the lambda | Uncaught exception kills only that thread (default handler prints trace) – result is lost unless you record it |
| Result ordering / collection | Futures give ordered results | Needs thread-safe collection or `collect()` | Needs manual `join` for 10,000 threads |

The `ExecutorService` approach gives control over concurrency, a clean per-task failure model and bounded memory, so it is the most suitable. (Java 21 virtual threads – `Executors.newVirtualThreadPerTaskExecutor()` – would make "one thread per file" cheap, but the platform-thread version above is not.)
