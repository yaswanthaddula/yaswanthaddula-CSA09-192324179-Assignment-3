import java.lang.management.*;

/** Task 6 Part A - hostel wallet transfers: deadlock version, then lock-ordering fix. */
public class WalletDeadlock {

    static class Account {
        final int id; int balance;
        Account(int id, int balance) { this.id = id; this.balance = balance; }
    }

    // Deadlock-prone: locks 'from' then 'to' (order depends on caller)
    static void transferUnsafe(Account from, Account to, int amt) throws InterruptedException {
        synchronized (from) {
            Thread.sleep(100);                 // widen the window so deadlock is reliable
            synchronized (to) { from.balance -= amt; to.balance += amt; }
        }
    }

    // Safe: always lock the account with the SMALLER id first
    static void transferSafe(Account from, Account to, int amt) throws InterruptedException {
        Account first = from.id < to.id ? from : to;
        Account second = first == from ? to : from;
        synchronized (first) {
            Thread.sleep(100);
            synchronized (second) { from.balance -= amt; to.balance += amt; }
        }
    }

    interface Transfer { void go(Account a, Account b, int amt) throws InterruptedException; }

    static Thread worker(String name, Transfer t, Account a, Account b) {
        Thread th = new Thread(() -> { try { t.go(a, b, 10); } catch (InterruptedException ignored) {} }, name);
        th.setDaemon(true);                    // so a deadlocked run cannot keep the JVM alive
        return th;
    }

    static void run(String title, Transfer t) throws InterruptedException {
        System.out.println("=== " + title + " ===");
        Account a = new Account(1, 1000), b = new Account(2, 1000);
        Thread t1 = worker("T1 (A->B)", t, a, b);
        Thread t2 = worker("T2 (B->A)", t, b, a);
        t1.start(); t2.start();
        t1.join(2000); t2.join(2000);
        ThreadMXBean mx = ManagementFactory.getThreadMXBean();
        if (t1.isAlive() && t2.isAlive()) {      // both still blocked after 2 s -> deadlock
            System.out.println("DEADLOCK detected between:");
            for (ThreadInfo ti : mx.getThreadInfo(new long[]{t1.getId(), t2.getId()}))
                System.out.println("  " + ti.getThreadName() + " is " + ti.getThreadState()
                        + ", waiting for a lock held by " + ti.getLockOwnerName());
        } else {
            System.out.println("Completed. Balances: A=" + a.balance + " B=" + b.balance + " (total " + (a.balance + b.balance) + ")");
        }
        System.out.println();
    }

    public static void main(String[] args) throws InterruptedException {
        run("Part A1: unordered locking", WalletDeadlock::transferUnsafe);
        run("Part A2: lock ordering by id", WalletDeadlock::transferSafe);
    }
}
