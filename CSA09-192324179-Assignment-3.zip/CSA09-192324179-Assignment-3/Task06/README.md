# Task 6 – Deadlock and Inter-Thread Communication (K4 – Analyse)

Files: `TokenCounter.java` (Complete the Code), `WalletDeadlock.java`, `OUTPUT.md`
Run: `cd Task06 && javac *.java && java WalletDeadlock` and `java TokenCounter` (several times)

## Shared Group Work
- **Part A:** `WalletDeadlock` runs two transfers A→B and B→A. First with unordered locking (deadlocks, detected through `ThreadInfo`), then with lock ordering (completes, total money unchanged).
- **Part B:** `TokenCounter` is a bounded buffer (capacity 5) with `wait()` / `notifyAll()`, one cook (producer) and two students (consumers).

## Student A – Producer–Consumer Design

### Why `wait()` must be in a synchronized block and in a loop
- **synchronized:** `wait()` releases the object's monitor and must own it, otherwise `IllegalMonitorStateException`. Holding the lock also makes "check condition then wait" atomic – without it a `notify()` between the check and the wait would be **lost** (lost wake-up).
- **loop:** after being woken, the thread must re-check the condition because (1) with several consumers another thread may have taken the token first, (2) `notifyAll()` wakes threads for conditions that may not hold for them, (3) **spurious wake-ups** are allowed. `while (count == 0) wait();` guarantees the thread proceeds only when the condition is truly satisfied.

### notify() vs notifyAll()
Producers and consumers wait on the **same monitor**. `notify()` wakes just one arbitrary waiting thread; it might wake a consumer when the buffer is empty (it goes back to wait and the signal is wasted) or wake a producer when a producer should not run – while the thread that could really proceed sleeps ⇒ the program can **hang**. My design uses `notifyAll()` after each `put`/`take`, so every waiter re-checks its condition and progress is guaranteed; `notify()` would only be safe with one kind of waiter or separate condition queues (`Condition` objects).

### Counter size over time
Add inside `put` (after `count++`) and `take` (after `count--`): `System.out.println("size=" + count);` and run once. The values stay between 0 and 5 because `put` waits at 5 and `take` waits at 0 (paste the printed sequence into `OUTPUT.md`, or show min/max).

### sleep() vs wait()

| | `Thread.sleep(ms)` | `Object.wait()` |
|---|---|---|
| Class | Thread (static) | Object (instance) |
| Monitor | **keeps** any locks it holds | **releases** the monitor while waiting |
| Needs synchronized | No | Yes |
| Wakes up | After time elapses (or interrupt) | `notify`/`notifyAll`, timeout, or interrupt |
| Purpose | Pause | Wait for a condition (coordination) |

## Student B – Deadlock Analysis and Prevention

### Reliable deadlock
T1 transfers A→B (locks A, sleeps 100 ms, wants B); T2 transfers B→A (locks B, sleeps, wants A). Output:
```
DEADLOCK detected between:
  T1 (A->B) is BLOCKED, waiting for a lock held by T2 (B->A)
  T2 (B->A) is BLOCKED, waiting for a lock held by T1 (A->B)
```
You can also take a thread dump with `jstack <pid>` (shows "Found one Java-level deadlock").

### The four conditions (all present)
1. **Mutual exclusion** – an account's monitor can be held by one thread only.
2. **Hold and wait** – each thread holds one account lock while waiting for the other.
3. **No preemption** – a monitor cannot be taken away from its owner.
4. **Circular wait** – T1 waits for T2's lock and T2 waits for T1's lock.

### Prevention: consistent lock ordering
`transferSafe` always locks the account with the **smaller id** first, then the larger one, regardless of transfer direction.

### Why it works
Ordering all locks gives a global sequence 1 < 2 < … Every thread acquires locks only in increasing order, so a thread holding lock k only ever waits for locks > k. A cycle (T1 → T2 → … → T1) would need some thread to wait for a lower-numbered lock – impossible. Circular wait is broken, so deadlock cannot occur (the other three conditions still hold). Output: `Completed. Balances: A=1000 B=1000`.

## Joint Conclusion
Both are about threads **waiting for something that only another thread can provide** (a lock, or a token / free slot), so progress depends on correct coordination. Deadlock design ensures progress by *breaking one of the four conditions* (here circular wait via lock ordering). Producer–consumer ensures progress with *condition waiting*: each state change (`put`/`take`) calls `notifyAll()`, waiters re-check the condition in a `while` loop, and the producer and consumers can always eventually proceed because the buffer is never left both full and unsignalled.

## Complete the Code – answers
`put`: `while (count == buffer.length) wait(); buffer[in] = token; in = (in+1) % buffer.length; count++; notifyAll();`
`take`: `while (count == 0) wait(); int t = buffer[out]; out = (out+1) % buffer.length; count--; notifyAll(); return t;`
Expected output: `Sum of tokens collected: 210 (expected 210)` (1+2+…+20 = 210).

**Change `while` to `if`:** with two consumers, both can be waiting on an empty buffer; when one token arrives and `notifyAll()` wakes both, the first consumer takes it; the second then continues **without re-checking** and reads an empty slot (a stale/zero value) and makes `count` negative (−1), corrupting the buffer state. Observed in my test of 6 runs: 5 runs still printed 210 by luck, but one run printed `Sum of tokens collected: 135 (expected 210)` – tokens were lost/duplicated. The bug is timing-dependent (intermittent), which is exactly why it is dangerous; run it 10–20 times and record what *you* observe.

## Alternative Concept and Complexity Analysis

```java
// Part B with ArrayBlockingQueue
BlockingQueue<Integer> q = new ArrayBlockingQueue<>(5);
q.put(token);            // blocks while full
int t = q.take();        // blocks while empty

// Part A with tryLock and timeout
if (first.lock.tryLock(50, MILLISECONDS)) try {
    if (second.lock.tryLock(50, MILLISECONDS)) try { transfer(); return true; }
    finally { second.lock.unlock(); }
} finally { first.lock.unlock(); }
return false;   // give up / retry later (back-off to avoid livelock)
```

| Design | Time per operation | Space |
|---|---|---|
| wait/notifyAll buffer | O(1) per put/take (but `notifyAll` wakes all waiters: O(w) wake-ups, w = waiting threads) | O(5) array + 3 ints |
| ArrayBlockingQueue | O(1) per put/take (one internal lock, two conditions → only the right waiter is signalled) | O(capacity) array + lock objects |
| Lock ordering | O(1) – two lock acquisitions per transfer | O(1) extra (no extra structure) |
| tryLock with timeout | O(1) per attempt, but may need retries (extra time, up to the timeout per failed attempt) | O(1) + lock objects |

**Less error-prone:** `ArrayBlockingQueue` (no manual wait/notify, no loops, no lost wake-ups) and, for Part A, lock ordering is simple and deterministic; `tryLock` avoids deadlock too but needs retry/back-off logic and can cause livelock or failed transfers, so it is more complex to get right.
