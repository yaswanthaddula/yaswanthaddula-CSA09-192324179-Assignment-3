# Task 5 – Race Conditions in a Cinema Seat-Booking System (K4 – Analyse)

Files: `SeatBooking.java` (Complete the Code – synchronized), `SeatBookingUnsafe.java` (TODO 1 without `synchronized`), `SeatBookingBench.java` (timing), `OUTPUT.md`
Run: `cd Task05 && javac *.java`
1. `java SeatBookingUnsafe` – run **10 times**, record "Seats sold" each time.
2. `java SeatBooking` – run 10 times; always `Seats sold: 10`.
3. `java SeatBookingBench` – timing of 10,000 bookings (use rounds 2–3; round 1 is JIT warm-up).

## Shared Group Work
- Unsynchronized version: `book()` checks `!booked[seat]` and then sets it – two steps.
- Synchronized method version: `synchronized void book(int seat)`.
- Synchronized block version: `synchronized (this) { check + set }` (in `SeatBookingBench.SyncBlock`).
- Verification: synchronized versions always give `sold = number of seats` (10 / 1000).

## Student A – Producing and Explaining the Race

### Reliable reproduction
`SeatBookingUnsafe` releases all 100 threads at the same instant with a `CountDownLatch`, and `Thread.sleep(1)` between the check and the booking widens the window, so every run double-books (the reference run printed values like 55, 54, 69, 44, 49 instead of 10).

### Double bookings over 10 runs (fill from your runs)

| Run | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
|---|---|---|---|---|---|---|---|---|---|---|
| Seats sold (correct = 10) | | | | | | | | | | |
| Double bookings = sold − 10 | | | | | | | | | | |

### Step-by-step interleaving (two users, same seat 3)

| Step | Thread U1 | Thread U2 | `booked[3]` |
|---|---|---|---|
| 1 | reads `booked[3]` → false (free) | | false |
| 2 | | reads `booked[3]` → false (U1 has not written yet) | false |
| 3 | writes `booked[3] = true`, `bookingsMade++` | | true |
| 4 | | writes `booked[3] = true`, `bookingsMade++` | true |

Both saw "free" ⇒ the seat is sold twice and `bookingsMade` is incremented twice. (`bookingsMade++` itself is also a non-atomic read-modify-write – a second race.)

### Critical section
```java
if (!booked[seat]) { booked[seat] = true; bookingsMade++; }
```
The check, the write and the counter update must execute as one indivisible unit.

## Student B – Comparing Synchronization Strategies

### Timing of 10,000 bookings (fill from `SeatBookingBench`, ms)

| Strategy | Round 2 | Round 3 | Correct (sold = 1000)? |
|---|---|---|---|
| Unsynchronized | | | No |
| synchronized method | | | Yes |
| synchronized block | | | Yes |
| ReentrantLock | | | Yes |
| AtomicBoolean[] (CAS) | | | Yes |
| ConcurrentHashMap.putIfAbsent | | | Yes |

### Whole method vs critical section only
The method version holds the lock while doing the non-critical `paymentWork()` (calculation), so all other threads wait for it. The block version does the payment work *outside* the lock and locks only the check-and-set – threads work in parallel and hold the lock for a very short time. Expect `SyncBlock` to be faster than `SyncMethod` when there is substantial non-critical work. If the whole body is critical (as in the plain assignment code) the two are equivalent.

### Static synchronization
`static synchronized` locks the **Class object** (`SeatBooking.class`), shared by all instances. It is needed when the shared data is *static* (e.g. a static counter of tickets across all screens). Here `booked[]` is per-screen instance data, so instance locks are right; a static lock would make bookings of different screens wait for each other for no reason.

### Intrinsic lock used
- synchronized instance method → intrinsic (monitor) lock of `this` (the `SeatBooking` object / screen).
- synchronized block → the lock of the object in parentheses (`this` here).
- (static synchronized → lock of `SeatBooking.class`.)
Each Java object has one monitor; only one thread at a time can own it; entry is re-entrant.

## Joint Engineering Decision – 20 screens
Create **one `SeatBooking` object per screen** and use a synchronized block (or `ReentrantLock`) on that object, with only the check-and-set inside the lock. Bookings for different screens run fully in parallel (different locks) and only users competing for the same screen contend. Do not use static synchronization or one global lock (would serialise all 20 screens). If a single popular screen has very high contention, use per-seat `AtomicBoolean.compareAndSet` (or `AtomicBooleanArray`) so different seats never block one another.

## Complete the Code – answer
Expected output with synchronized: `Seats sold: 10`.
**Why the unsynchronized version can sell more than 10:** ten threads compete for each seat; several can read `booked[seat] == false` before any of them writes `true` (check-then-act race), so each of them executes `bookingsMade++`. Hence the count may be above 10 (and, because `++` is not atomic, occasionally lost updates can make results differ in other ways).

## Alternative Concept and Complexity Analysis

```java
// 1. CAS
AtomicBoolean[] seat = ...;     if (seat[i].compareAndSet(false, true)) sold.incrementAndGet();
// 2. ReentrantLock
lock.lock(); try { if (!booked[i]) { booked[i] = true; n++; } } finally { lock.unlock(); }
// 3. ConcurrentHashMap
if (map.putIfAbsent(i, TRUE) == null) sold.incrementAndGet();
```

| Approach | Time per booking under contention | Extra space for s seats |
|---|---|---|
| synchronized | O(1) when free; threads queue (OS-level blocking) – wait grows with the number of competing threads k, ≈ O(k) | none beyond `boolean[s]` (O(s)); one monitor in the object header |
| ReentrantLock | O(1) uncontended; O(k) waiting; supports `tryLock`, fairness | O(s) + one lock object (+ queue node per waiting thread) |
| AtomicBoolean[] CAS | lock-free: O(1) per attempt, failed CAS means the seat is taken (no retry needed) – no blocking | s objects: O(s) with larger constant (~16–24 bytes each + reference) |
| ConcurrentHashMap.putIfAbsent | expected O(1), fine-grained bin locking | O(s) entries (~40–50 bytes each) – largest |

All are O(s) in space asymptotically; the constants differ. CAS gives the best scalability under high contention; `synchronized` is simplest and the JVM optimises it well.
