import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.concurrent.locks.ReentrantLock;

/** Task 5 Student B - time 10,000 bookings (1,000 seats) for every strategy with 8 worker threads. */
public class SeatBookingBench {
    static final int SEATS = 1000, BOOKINGS = 10_000, THREADS = 8;

    interface Booker { void book(int seat); int sold(); }

    static void paymentWork() {               // non-critical work done for every booking
        double x = 0; for (int i = 0; i < 2000; i++) x += Math.sqrt(i);
        if (x < 0) System.out.print("");
    }

    static class Unsafe implements Booker {
        boolean[] b = new boolean[SEATS]; int n;
        public void book(int s) { paymentWork(); if (!b[s]) { b[s] = true; n++; } }
        public int sold() { return n; }
    }
    static class SyncMethod implements Booker {
        boolean[] b = new boolean[SEATS]; int n;
        public synchronized void book(int s) { paymentWork(); if (!b[s]) { b[s] = true; n++; } }   // lock held during work
        public synchronized int sold() { return n; }
    }
    static class SyncBlock implements Booker {
        boolean[] b = new boolean[SEATS]; int n;
        public void book(int s) { paymentWork(); synchronized (this) { if (!b[s]) { b[s] = true; n++; } } } // lock only critical part
        public synchronized int sold() { return n; }
    }
    static class Cas implements Booker {
        AtomicBoolean[] b = new AtomicBoolean[SEATS]; AtomicInteger n = new AtomicInteger();
        Cas() { for (int i = 0; i < SEATS; i++) b[i] = new AtomicBoolean(); }
        public void book(int s) { paymentWork(); if (b[s].compareAndSet(false, true)) n.incrementAndGet(); }
        public int sold() { return n.get(); }
    }
    static class Reentrant implements Booker {
        boolean[] b = new boolean[SEATS]; int n; ReentrantLock lock = new ReentrantLock();
        public void book(int s) { paymentWork(); lock.lock(); try { if (!b[s]) { b[s] = true; n++; } } finally { lock.unlock(); } }
        public int sold() { return n; }
    }
    static class PerSeatMap implements Booker {
        ConcurrentHashMap<Integer, Boolean> m = new ConcurrentHashMap<>();
        public void book(int s) { paymentWork(); m.putIfAbsent(s, Boolean.TRUE); }
        public int sold() { return m.size(); }
    }

    static void time(String name, Booker bk) throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(THREADS);
        long t0 = System.nanoTime();
        for (int i = 0; i < BOOKINGS; i++) { final int seat = i % SEATS; pool.submit(() -> bk.book(seat)); }
        pool.shutdown(); pool.awaitTermination(1, TimeUnit.MINUTES);
        long ms = (System.nanoTime() - t0) / 1_000_000;
        System.out.printf("%-14s sold=%d (correct=%d)  time=%d ms%n", name, bk.sold(), SEATS, ms);
    }

    public static void main(String[] a) throws Exception {
        for (int round = 1; round <= 3; round++) {         // round 1 = JIT warm-up, use rounds 2-3
            System.out.println("--- round " + round + " ---");
            time("Unsafe", new Unsafe());
            time("SyncMethod", new SyncMethod());
            time("SyncBlock", new SyncBlock());
            time("ReentrantLock", new Reentrant());
            time("AtomicBoolean", new Cas());
            time("PutIfAbsent", new PerSeatMap());
        }
    }
}
