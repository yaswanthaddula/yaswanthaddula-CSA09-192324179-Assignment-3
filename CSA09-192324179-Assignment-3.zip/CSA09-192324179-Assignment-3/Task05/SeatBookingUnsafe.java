/**
 * Task 5 - UNSYNCHRONIZED version (TODO 1 written WITHOUT the synchronized keyword).
 * Thread.sleep(1) between check and act (plus a start gate) widens the race window so double booking is reproducible.
 * Run this 10 times and record "Seats sold" each time (expected 10, but it will often be > 10).
 */
public class SeatBookingUnsafe {
    private final boolean[] booked;
    private int bookingsMade = 0;
    SeatBookingUnsafe(int seats) { booked = new boolean[seats]; }

    void book(int seat) {                 // NOT synchronized
        if (!booked[seat]) {              // check
            try { Thread.sleep(1); } catch (InterruptedException e) { }   // another thread can slip in here
            booked[seat] = true;          // act
            bookingsMade++;
        }
    }

    public static void main(String[] args) throws InterruptedException {
        SeatBookingUnsafe screen = new SeatBookingUnsafe(10);
        Thread[] users = new Thread[100];
        java.util.concurrent.CountDownLatch gate = new java.util.concurrent.CountDownLatch(1);
        for (int i = 0; i < users.length; i++) {
            final int seat = i % 10;
            users[i] = new Thread(() -> { try { gate.await(); } catch (InterruptedException e) { } screen.book(seat); });
            users[i].start();
        }
        gate.countDown();                 // release all 100 users at the same instant
        for (Thread t : users) t.join();
        System.out.println("Seats sold: " + screen.bookingsMade + "  (correct answer is 10)");
    }
}
