public class StackTraceDemo {
    public static void main(String[] args) {
        System.out.println("Before the failure");
        int account = Integer.parseInt("10A1");   // NumberFormatException is NOT caught -> program crashes
        System.out.println("Never printed " + account);
    }
}
