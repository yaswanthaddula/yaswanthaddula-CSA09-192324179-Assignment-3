import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 * Task 1 - ATM withdrawal with try / catch (multi-catch) / finally.
 * Run from inside the Task01 folder so that card.txt is found.
 */
public class AtmWithdrawal {

    // Checked custom exception: a business rule the caller must handle
    static class InsufficientFundsException extends Exception {
        InsufficientFundsException(String message) { super(message); }
    }

    static double balance = 5000.0;

    // FileNotFoundException / IOException are CHECKED
    static void readCard(String cardFile) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(cardFile))) {
            br.readLine();
        }
    }

    static void withdraw(String cardFile, String accText, String amtText)
            throws IOException, InsufficientFundsException {
        readCard(cardFile);                              // failure point 1: card reader file
        int account = Integer.parseInt(accText);         // failure point 2: NumberFormatException (unchecked)
        double amount = Double.parseDouble(amtText);     // failure point 3: NumberFormatException (unchecked)
        if (amount <= 0)                                 // failure point 4: negative / zero amount
            throw new IllegalArgumentException("Amount must be positive");
        if (amount > balance)                            // failure point 5: more than balance
            throw new InsufficientFundsException("Requested " + amount + " but balance is " + balance);
        balance -= amount;
        System.out.println("  Dispensed " + amount + " from account " + account + ". New balance = " + balance);
    }

    static void attempt(String label, String cardFile, String acc, String amt) {
        System.out.println("Test: " + label);
        try {
            withdraw(cardFile, acc, amt);
        } catch (FileNotFoundException e) {              // narrower IOException subclass FIRST
            System.out.println("  [catch FileNotFoundException] Card reader file missing: " + e.getMessage());
        } catch (IOException e) {                        // broader checked exception AFTER
            System.out.println("  [catch IOException] I/O problem: " + e.getMessage());
        } catch (NumberFormatException e) {              // subclass of IllegalArgumentException -> must be before it
            System.out.println("  [catch NumberFormatException] Not a number: " + e.getMessage());
        } catch (InsufficientFundsException | IllegalArgumentException e) {   // multi-catch (unrelated types)
            System.out.println("  [multi-catch " + e.getClass().getSimpleName() + "] " + e.getMessage());
        } finally {
            System.out.println("  [finally] Card returned to customer, session closed.");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        attempt("T1 valid withdrawal",           "card.txt",        "1001",  "1000");
        attempt("T2 letters instead of number",  "card.txt",        "10A1",  "500");
        attempt("T3 letters in amount",          "card.txt",        "1001",  "five hundred");
        attempt("T4 negative amount",            "card.txt",        "1001",  "-200");
        attempt("T5 amount exceeds balance",     "card.txt",        "1001",  "999999");
        attempt("T6 card reader file missing",   "missing_card.txt","1001",  "100");
    }
}
