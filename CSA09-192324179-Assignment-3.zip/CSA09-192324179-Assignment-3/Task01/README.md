# Task 1 – Handling Failure in a Bank ATM Simulation (K4 – Analyse)

Files: `AtmWithdrawal.java`, `StackTraceDemo.java`, `card.txt`, `OUTPUT.md`
Run: `cd Task01 && javac *.java && java AtmWithdrawal` then `java StackTraceDemo`

## Shared Group Work

### Failure points and classification

| # | Failure point | Exception | Category |
|---|---|---|---|
| 1 | Card-reader file missing | `FileNotFoundException` (subclass of `IOException`) | Checked |
| 2 | Card file unreadable / read error | `IOException` | Checked |
| 3 | Account number typed as letters | `NumberFormatException` | Unchecked |
| 4 | Amount typed as letters | `NumberFormatException` | Unchecked |
| 5 | Negative / zero amount | `IllegalArgumentException` | Unchecked |
| 6 | Amount greater than balance | `InsufficientFundsException` (custom, extends `Exception`) | Checked |
| 7 | JVM out of memory, stack overflow while running | `OutOfMemoryError`, `StackOverflowError` | Error (not caught) |

Implementation: see `AtmWithdrawal.java` (try, multi-catch `InsufficientFundsException | IllegalArgumentException`, finally). Test with 6 inputs T1–T6.

## Student A – Exception Design

### Throwable hierarchy relevant to the ATM

```
Throwable
├── Error                                  (unchecked – never caught here)
│   ├── OutOfMemoryError
│   └── StackOverflowError
└── Exception
    ├── IOException                        (CHECKED)
    │   └── FileNotFoundException          (CHECKED)
    ├── InsufficientFundsException         (CHECKED, custom)
    └── RuntimeException                   (UNCHECKED)
        └── IllegalArgumentException
            └── NumberFormatException
```

### Failure → exception → checked? → where caught

| Failure point | Exception type | Checked/Unchecked | Where it is caught |
|---|---|---|---|
| Card file missing | FileNotFoundException | Checked | `catch (FileNotFoundException e)` in `attempt()` |
| Card read error | IOException | Checked | `catch (IOException e)` in `attempt()` |
| Letters in account/amount | NumberFormatException | Unchecked | `catch (NumberFormatException e)` |
| Negative amount | IllegalArgumentException | Unchecked | multi-catch |
| Amount > balance | InsufficientFundsException | Checked | multi-catch |

### Justification of catch order
Java checks catch blocks top-to-bottom and uses the first one that matches. A catch for a **subclass must come before its superclass**, otherwise the subclass block is unreachable and the compiler rejects it.
- `FileNotFoundException` before `IOException` (subclass first).
- `NumberFormatException` before `IllegalArgumentException` (it is a subclass; it also cannot be in the same multi-catch because multi-catch alternatives may not be related by inheritance).
- The most specific message is therefore shown to the customer.

### What `finally` guarantees
The `finally` block runs on every path – normal completion, any caught exception, and even an uncaught exception (before it propagates). In this program it guarantees that "card returned / session closed" is executed for all six tests, so a customer's card is never kept after a failure. (Only `System.exit()` or a JVM crash skips it.)

## Student B – Testing and Tracing

### Test table

| Test | Input (card, account, amount) | Path triggered | Catch block executed | `finally` executed? |
|---|---|---|---|---|
| T1 | card.txt, 1001, 1000 | Normal | none | Yes |
| T2 | card.txt, 10A1, 500 | NumberFormatException (account) | `catch (NumberFormatException)` | Yes |
| T3 | card.txt, 1001, five hundred | NumberFormatException (amount) | `catch (NumberFormatException)` | Yes |
| T4 | card.txt, 1001, -200 | IllegalArgumentException | multi-catch | Yes |
| T5 | card.txt, 1001, 999999 | InsufficientFundsException | multi-catch | Yes |
| T6 | missing_card.txt, 1001, 100 | FileNotFoundException | `catch (FileNotFoundException)` | Yes |

(Verify the "observed" behaviour against your own `OUTPUT.md`.)

### Stack trace of an uncaught exception (`StackTraceDemo`)
Typical output (line numbers on your machine may differ – paste yours in `OUTPUT.md`):

```
Exception in thread "main" java.lang.NumberFormatException: For input string: "10A1"
	at java.base/java.lang.NumberFormatException.forInputString(NumberFormatException.java:67)
	at java.base/java.lang.Integer.parseInt(Integer.java:662)
	at java.base/java.lang.Integer.parseInt(Integer.java:778)
	at StackTraceDemo.main(StackTraceDemo.java:4)
```

| Line | Meaning |
|---|---|
| 1 | Thread name (`main`), exception class and detail message (the bad text) |
| 2 | Where the exception object was created (`forInputString`) – deepest frame |
| 3–4 | The JDK methods `parseInt` that called it |
| 5 | **Our code**: `main` at line 4 called `parseInt` – the line to fix |

Frames read from top (where it happened) to bottom (who called whom). Because nothing caught it, the thread terminated and "Never printed" was not shown.

### Broader catch before narrower
```java
try { ... }
catch (IOException e)           { }
catch (FileNotFoundException e) { }   // compile error
```
`javac` reports: `error: exception FileNotFoundException has already been caught`. The narrower block could never run, so Java rejects the program at compile time.

## Joint Design Question – single `catch (Exception e)`?
Acceptable only at a **top-level boundary** (e.g. the ATM main loop or a request handler) that logs the problem, shows a generic message and keeps the ATM alive, and as a last block after specific ones. What is lost: the ability to respond differently (retry for bad input vs. call technician for missing file), the distinction between recoverable and fatal problems, bugs such as `NullPointerException` get silently swallowed, and it also catches `InterruptedException`/runtime programming errors. It tells the user nothing specific and makes testing harder.

## Alternative Concept and Complexity Analysis – error codes instead of exceptions

```java
// no exceptions: pre-check and return codes
static int withdraw(Scanner in, double balance) {
    if (!cardFileExists("card.txt"))  return -3;
    if (!in.hasNextInt())             return -1;   // letters in account
    int acc = in.nextInt();
    if (!in.hasNextDouble())          return -1;
    double amt = in.nextDouble();
    if (amt <= 0)                     return -2;
    if (amt > balance)                return -4;
    return 0;                         // success
}
// caller:  int rc = withdraw(...);  if (rc == -1) ... else if (rc == -2) ...
```
- **Readability:** normal logic is mixed with checks; every caller must remember to test the code (easy to forget – failures are silently ignored); magic numbers. Exceptions separate the happy path from error handling and cannot be ignored (checked ones).
- **Number of checks:** error codes need one explicit check per failure point on every call (≈ 5–6 `if`s even for valid input); exceptions cost no checks on the success path.
- **Time:** returning a code is O(1) and very cheap. Creating + throwing an exception is O(d), d = stack depth, because `fillInStackTrace()` walks the whole call stack, plus unwinding to the handler (typically microseconds vs nanoseconds). On the success path both are O(1).
- **Space:** an error code uses O(1) (one int). An exception object holds a stack trace – O(d) memory (hundreds of bytes to KBs). Therefore exceptions are for *exceptional* conditions; for expected, frequent bad input (like typos) pre-validation is cheaper.
