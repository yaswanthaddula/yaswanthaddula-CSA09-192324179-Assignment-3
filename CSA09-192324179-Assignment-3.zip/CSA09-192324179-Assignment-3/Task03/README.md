# Task 3 – Resource Safety, Debugging and Robust Code (K4 – Analyse)

Files: `ReportGenerator.java`, `OUTPUT.md`
Run: `cd Task03 && javac ReportGenerator.java && java ReportGenerator`
The program creates three store files in a temp folder (`store2.txt` is deliberately corrupt: line 2 is `abc`) and runs three versions:
1. **LEAKY** – `close()` is called at the end of the `try`, not in `finally`.
2. **MANUAL** – try–catch–finally with manual `close()`.
3. **TRY-WITH-RESOURCES**.
`TrackedReader` counts open readers so that leaks are measurable.

## Shared Group Work
- Both correct versions produce the same total (`350.0`) and identical summary files (program prints `true`).
- Observed (reference run):
```
LEAKY (no finally)     : total = 350.0 | files still open = 1
MANUAL try-catch-final : total = 350.0 | files still open = 0
TRY-WITH-RESOURCES     : total = 350.0 | files still open = 0
```

## Student A – Debugging and Experimental Analysis

### Locating the leak with the debugger
1. Put a breakpoint on the line `TrackedReader r = new TrackedReader(path);` in `sumFileLeaky`, and another on `r.close();`.
2. Debug (F5 in VS Code / Eclipse / IntelliJ), watch the variable `openHandles` (add it to *Watches*).
3. Step over (F8/F10) through `store2.txt`: after `store1` the count is 0; opening `store2` makes it 1; stepping `Double.parseDouble("abc")` throws `NumberFormatException` and execution jumps out of the method **without ever reaching `r.close()`** – `openHandles` stays 1. That jump is the leak point.

### Input that makes the manual version fail part-way
`store2.txt` = `300 / abc / 400` – the first line is read, the second throws.
For `f` files that all fail this way, the leaky version leaves `f` readers open (here f_fail = 1).

### Files left open for the same failing input

| Version | Files left open |
|---|---|
| Leaky (no finally) | 1 per failing file (1 in this test) |
| Manual try-catch-finally | 0 |
| try-with-resources | 0 |

### Logging
`LOG.severe("[version] failure while reading file: <path> -> <exception>")` is written in `run()` – the log line names the exact file that caused the failure (paste the log lines in `OUTPUT.md`).

## Student B – Design and Correctness

### Resources and where they must be closed

| Resource | Opened | Must be closed |
|---|---|---|
| `FileReader` / `BufferedReader` (one per store file) | start of `sumFile…` | before leaving `sumFile…` (success or failure) |
| `BufferedWriter` for summary file | in `run()` | after writing total (also flushes data) |

### Why the manual version can leak
If `readLine()` or `parseDouble()` throws, control leaves the method before `close()`. Even a manual `finally` is easy to get wrong: if `close()` is inside `try`, if the resource variable is null, or when closing several resources and the first `close()` throws – the others are never closed. Too many leaked handles ⇒ "Too many open files". An unclosed writer can also leave **buffered data unflushed**, producing the incomplete report.

### How try-with-resources guarantees closing and the order
The compiler generates a hidden `finally` that calls `close()` on every initialised resource, whether the body finishes normally or throws. Resources are closed in **reverse order of declaration** (last opened, first closed) – the demo prints `close B` then `close A`. Even if one `close()` throws, the others are still closed.

### Suppressed exception
If the body throws an exception *and* `close()` also throws, the body's exception stays the primary one; the exception from `close()` is attached to it with `addSuppressed()` and can be read with `getSuppressed()` (demo prints the two `close failed` exceptions as suppressed). Without it the close error would hide the real cause (as happens in manual `finally`).

## Joint Engineering Decision – when is try-with-resources not enough?
- When a resource's lifetime must outlive the block (opened in one method, used/closed in another, or kept in a pool).
- When the *close failure itself matters* (e.g. `BufferedWriter.close()` flush fails ⇒ the report is incomplete) – the exception must be checked/handled, not just suppressed.
- When a failure leaves a **half-written summary file** – need write-to-temp-file and atomic rename.
- When resources are not `AutoCloseable` (wrap them) or are acquired through non-resource APIs.
- When the system limit of handles is hit by concurrency (many files open at once) – needs throttling.
- When error policy is needed: skip file, retry, or abort the whole report – try-with-resources only handles cleanup, not business logic.

## Alternative Concept and Complexity Analysis
Alternatives: (a) explicit `close()` in `finally`, (b) no closing at all (rely on GC/finalisation).

```java
// (a) explicit finally
BufferedReader r = null;
try { r = new BufferedReader(new FileReader(p)); ... }
finally { if (r != null) try { r.close(); } catch (IOException e) { /* log */ } }
// (b) no closing: r = new BufferedReader(...); ... // handle stays open until GC
```

For a report of **f store files** with L total lines:

| Version | Time to process | Max open file handles (space) when a failure occurs |
|---|---|---|
| try-with-resources | O(L) (reading dominates; close is O(1) each, O(f) total) | 1 (sequential) – closed immediately on failure |
| explicit finally | O(L) | 1 – also closed, but only if coded correctly |
| no closing / close only on success | O(L) | grows with failures: up to **f** handles held (one per failing file), until GC runs; if all files are opened first, f open at once |

Time is the same in all versions because each line is read once; the difference is **space (handles)** and **correctness**. try-with-resources has the same cost as manual finally but fewer lines and no chance to forget the close.
