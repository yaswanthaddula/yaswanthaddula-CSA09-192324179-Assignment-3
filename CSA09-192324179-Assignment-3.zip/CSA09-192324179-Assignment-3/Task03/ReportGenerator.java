import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.logging.*;

/** Task 3 - Daily Sales Report: leaky version vs manual finally vs try-with-resources. */
public class ReportGenerator {

    static final Logger LOG = Logger.getLogger("report");
    static int openHandles = 0;                     // how many readers are currently open

    /** BufferedReader that counts open/close so we can PROVE leaks. */
    static class TrackedReader extends BufferedReader {
        private boolean closed = false;
        TrackedReader(String path) throws IOException {
            super(new FileReader(path));
            openHandles++;
        }
        @Override public void close() throws IOException {
            if (!closed) { closed = true; openHandles--; }
            super.close();
        }
    }

    static double sumFileLeaky(String path) throws IOException {          // close() NOT in finally
        TrackedReader r = new TrackedReader(path);
        double s = 0; String line;
        while ((line = r.readLine()) != null) s += Double.parseDouble(line.trim());   // may throw -> leak
        r.close();
        return s;
    }

    static double sumFileFinally(String path) throws IOException {        // manual try-catch-finally
        TrackedReader r = null;
        try {
            r = new TrackedReader(path);
            double s = 0; String line;
            while ((line = r.readLine()) != null) s += Double.parseDouble(line.trim());
            return s;
        } finally {
            if (r != null) {
                try { r.close(); } catch (IOException e) { LOG.warning("close failed: " + e); }
            }
        }
    }

    static double sumFileTwr(String path) throws IOException {            // try-with-resources
        try (TrackedReader r = new TrackedReader(path)) {
            double s = 0; String line;
            while ((line = r.readLine()) != null) s += Double.parseDouble(line.trim());
            return s;
        }
    }

    interface FileSummer { double sum(String path) throws IOException; }

    static double run(String name, FileSummer summer, List<String> files, Path summary) throws IOException {
        openHandles = 0;
        double total = 0;
        for (String f : files) {
            try {
                total += summer.sum(f);
            } catch (IOException | NumberFormatException e) {
                LOG.severe("[" + name + "] failure while reading file: " + f + " -> " + e);   // logs WHICH file
            }
        }
        try (BufferedWriter w = Files.newBufferedWriter(summary)) {
            w.write("TOTAL SALES = " + total + "\n");
        }
        System.out.println(name + ": total = " + total + " | files still open = " + openHandles);
        return total;
    }

    // ---------- suppressed exception demo ----------
    static class Res implements AutoCloseable {
        final String name;
        Res(String name) { this.name = name; System.out.println("  open " + name); }
        @Override public void close() throws Exception {
            System.out.println("  close " + name);
            throw new IllegalStateException("close failed for " + name);
        }
    }

    static void suppressedDemo() {
        System.out.println("\nSuppressed exception demo (closing order is reverse of opening):");
        try (Res a = new Res("A"); Res b = new Res("B")) {
            throw new RuntimeException("body failed");
        } catch (Exception e) {
            System.out.println("  primary   : " + e);
            for (Throwable t : e.getSuppressed()) System.out.println("  suppressed: " + t);
        }
    }

    public static void main(String[] args) throws IOException {
        Path dir = Files.createTempDirectory("sales");
        Files.writeString(dir.resolve("store1.txt"), "100\n200\n");
        Files.writeString(dir.resolve("store2.txt"), "300\nabc\n400\n");      // corrupt in the middle
        Files.writeString(dir.resolve("store3.txt"), "50\n");
        List<String> files = List.of(dir.resolve("store1.txt").toString(),
                                     dir.resolve("store2.txt").toString(),
                                     dir.resolve("store3.txt").toString());

        run("LEAKY (no finally)     ", ReportGenerator::sumFileLeaky,   files, dir.resolve("s1.txt"));
        run("MANUAL try-catch-final ", ReportGenerator::sumFileFinally, files, dir.resolve("s2.txt"));
        run("TRY-WITH-RESOURCES     ", ReportGenerator::sumFileTwr,     files, dir.resolve("s3.txt"));

        System.out.println("\nSummary files identical (manual vs twr)? "
                + Files.readString(dir.resolve("s2.txt")).equals(Files.readString(dir.resolve("s3.txt"))));
        suppressedDemo();
    }
}
