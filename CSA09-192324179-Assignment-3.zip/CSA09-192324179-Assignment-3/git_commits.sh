#!/bin/bash
# Run inside your cloned repo after copying these folders into it.
# One commit per task (the assignment checks the commit history).
git add README.md CSA09_192324179_Assignment3_Report.docx && git commit -m "Add README and report"
for t in Task01 Task02 Task03 Task04 Task05 Task06 Task07; do
  git add $t && git commit -m "$t: code, README and output"
done
git push origin main
