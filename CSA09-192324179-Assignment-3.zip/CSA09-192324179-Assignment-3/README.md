# CSA09 – Programming in Java – Assignment 3 (CO3)

**Name:** A. Yaswanth
**Register Number:** 192324179
**Java version:** (paste output of `java -version`)
**Partner (Student B):** (name / register number)

Topics: Exception handling and multithreading (Sessions 27–38).

## Folder structure

| Folder | Task | Files |
|---|---|---|
| Task01 | ATM withdrawal – try/catch/finally | `AtmWithdrawal.java`, `StackTraceDemo.java`, `card.txt`, `README.md`, `OUTPUT.md` |
| Task02 | Exam portal – user-defined exceptions, chaining | `ExamPortal.java`, `StorageDemo.java`, `README.md`, `OUTPUT.md` |
| Task03 | Sales report – try-with-resources, debugging | `ReportGenerator.java`, `README.md`, `OUTPUT.md` |
| Task04 | Scanner stations – thread life cycle | `ScannerStations.java`, `ExecutorStations.java`, `README.md`, `OUTPUT.md` |
| Task05 | Cinema booking – race conditions | `SeatBooking.java`, `SeatBookingUnsafe.java`, `SeatBookingBench.java`, `README.md`, `OUTPUT.md` |
| Task06 | Deadlock + producer-consumer | `WalletDeadlock.java`, `TokenCounter.java`, `README.md`, `OUTPUT.md` |
| Task07 | Concurrent fault-tolerant processor | `ResultProcessor.java`, `README.md`, `OUTPUT.md` |

## How to compile and run (from the repository root)

```
cd Task01 && javac *.java && java AtmWithdrawal && java StackTraceDemo && cd ..
cd Task02 && javac *.java && java ExamPortal && java StorageDemo && cd ..
cd Task03 && javac *.java && java ReportGenerator && cd ..
cd Task04 && javac *.java && java ScannerStations && java ExecutorStations && cd ..
cd Task05 && javac *.java && java SeatBookingUnsafe && java SeatBooking && java SeatBookingBench && cd ..
cd Task06 && javac *.java && java WalletDeadlock && java TokenCounter && cd ..
cd Task07 && javac *.java && java ResultProcessor && cd ..
```

## Result summary (update after running)

| Task | Result |
|---|---|
| Task01 | Six ATM tests handled by different catch blocks; `finally` always executed |
| Task02 | Exceptions propagate controller ← service ← storage; cause preserved with chaining; `StorageDemo` matches expected output |
| Task03 | Leaky version leaves 1 file open; manual finally and try-with-resources leave 0; reports identical |
| Task04 | Output order varies between runs; `join()` gives the correct total |
| Task05 | Unsynchronized version double-books; synchronized version always prints `Seats sold: 10` |
| Task06 | Deadlock reproduced and fixed by lock ordering; `TokenCounter` prints 210 |
| Task07 | 10,000 files processed, successes + failures = 10,000, speed-up with more threads |

## Individual Contribution Record

| Task | Student A – Primary | Student B – Primary | Joint |
|---|---|---|---|
| Task01 | Exception design (hierarchy, table, catch order, finally) | Testing and tracing (5+ tests, stack trace, wrong catch order) | Implementation, single-catch discussion |
| Task02 | Hierarchy, checked/unchecked, propagation path | Failure scenarios, chaining evidence, lost cause | Implementation, conclusion |
| Task03 | Debugging, leak experiment, logging | Resource design, try-with-resources explanation, suppressed exceptions | Both versions, engineering decision |
| Task04 | Thread design, life cycle, run() vs start(), join() | 10-run experiment, priorities, daemon | Implementation, conclusion |
| Task05 | Reproduce and explain the race, critical section | Timing comparison, static sync, intrinsic locks | Implementations, deployment decision |
| Task06 | Producer-consumer design, wait/notify | Deadlock construction, four conditions, prevention | Implementations, conclusion |
| Task07 | Stage 2 design | Stage 3 implementation and measurement | Stages 1 and 4 |
