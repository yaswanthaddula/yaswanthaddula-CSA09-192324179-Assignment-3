# Task 2 – User-Defined Exceptions and Propagation in an Online Examination Portal (K4 – Analyse)

Files: `ExamPortal.java`, `StorageDemo.java` (Complete the Code), `OUTPUT.md`
Run: `cd Task02 && javac *.java && java ExamPortal` and `java StorageDemo`
(`ExamPortal` uses nested classes, so it compiles together with `StorageDemo.java` without name clashes.)

## Shared Group Work
- Hierarchy: `ExamException` (checked base) → `ExamClosedException`, `NotRegisteredException`, `FileTooLargeException`, `SubmissionStorageException`; plus unchecked `PortalConfigException extends RuntimeException`.
- `throw` in the service/storage layers, `throws ExamException` in method signatures, final handling in the controller.
- Chaining: the storage layer wraps `IOException` using `new SubmissionStorageException(msg, e)`.

## Student A – Hierarchy and Propagation Design

### Class diagram
```
            Throwable
               │
            Exception ─────────────┐
               │                   │
        ExamException         RuntimeException
   (checked, base of portal)       │
   ┌──────┬──────────┬────────┐    PortalConfigException
   │      │          │        │    (unchecked)
 ExamClosed  NotRegistered  FileTooLarge  SubmissionStorage
 Exception   Exception      Exception     Exception (has cause)
```

### Why checked / unchecked

| Exception | Type | Reason |
|---|---|---|
| ExamClosedException | Checked | Expected business situation; the caller can and must react (show message) |
| NotRegisteredException | Checked | Same – recoverable by contacting the office |
| FileTooLargeException | Checked | Student can fix by uploading a smaller file |
| SubmissionStorageException | Checked | Infrastructure failure the controller must translate into a friendly message/retry |
| PortalConfigException | Unchecked | Programming/configuration bug (null file name); no caller can sensibly recover, so not forced into every signature |

### Propagation path of `SubmissionStorageException`
```
StorageLayer.store()  --throws-->  SubmissionService.submit()  --throws-->  Controller.handle()
   (IOException caught,              (no catch; declared                        catch (SubmissionStorageException)
    wrapped & re-thrown)              throws ExamException)                      → final handling
```
It is finally handled in the **controller**. The student sees: *"Sorry, we could not save your answer. Try again."* – no technical text; the cause and stack trace go to the log.

## Student B – Failure Scenarios and Chaining Evidence

### Test table

| Scenario | Input | Exception thrown | Message seen by student |
|---|---|---|---|
| S1 valid | open, registered, 120 KB, disk OK | none | Submission successful |
| S2 window closed | windowOpen=false | ExamClosedException | Exam window closed for CSA09 |
| S3 not registered | registered=false | NotRegisteredException | Ravi is not registered for CSA09 |
| S4 too large | 900 KB | FileTooLargeException | big.pdf is 900 KB (limit 500 KB) |
| S5 storage fail | diskFull=true | SubmissionStorageException (cause IOException) | Sorry, we could not save your answer… |
| S6 config bug | file name null | PortalConfigException (unchecked) | not shown to student |

### Chained stack trace (`getCause()`)
`ExamPortal` prints `e.getCause()` and `e.printStackTrace()`. Expected shape:

```
ExamPortal$SubmissionStorageException: Could not store answer.pdf
	at ExamPortal$StorageLayer.store(ExamPortal.java:..)
	at ExamPortal$SubmissionService.submit(ExamPortal.java:..)
	at ExamPortal$Controller.handle(ExamPortal.java:..)
	...
Caused by: java.io.IOException: No space left on device
	at ExamPortal$StorageLayer.store(ExamPortal.java:..)
	... 5 more
```
`Caused by:` is the preserved original exception (`getCause()`); `... 5 more` means the remaining frames are identical to the enclosing trace.

### Information lost when re-thrown without cause
With `new SubmissionStorageException("Could not store answer.pdf", null)`, `getCause()` returns `null`, there is no `Caused by:` section, and the **real reason (disk full / IOException message) and the exact line where it started are gone** – developers can no longer diagnose the failure. (The method `lossyRethrow()` in `ExamPortal` demonstrates this.)

## Joint Conclusion – meaningful SubmissionStorageException vs raw IOException
- The UI layer should not depend on storage technology (files today, database/cloud tomorrow) – a domain exception keeps layers decoupled.
- It carries a meaningful, student-oriented message and a clear type to catch, whereas `IOException` is generic and could come from anywhere.
- Chaining keeps the technical cause for logs, so nothing is lost while the user sees a safe message (no leaking of paths/internal details).
- The controller can handle it specifically (retry / apologise).

## Complete the Code (`StorageDemo.java`)
TODO 1: `throw new SubmissionStorageException("Could not store " + fileName, e);`

Expected output:
```
Saved answer01.pdf
Error: Could not store answer02.pdf
Cause: Disk quota exceeded
```
**If the IOException were not passed to the constructor:** `getCause()` returns `null`, so `e.getCause().getMessage()` in `main` throws a **`NullPointerException`**; the "Error:" line prints, but the "Cause:" line is never printed (the program crashes with an NPE instead).

## Alternative Concept and Complexity Analysis – unchecked custom exceptions
If the exceptions extended `RuntimeException`:
- **Signatures:** no `throws` clauses needed on `save`, `submit`, `handle`; the compiler no longer forces callers to handle or declare them.
- **Calling code:** `try/catch` becomes optional – an unhandled one would travel to the top and crash the thread; developers might forget to handle it (less safe), but code is shorter and lambdas/streams can throw it freely. Existing `catch (ExamException e)` still compiles.
- **Time:** every exception calls `fillInStackTrace()` → O(d) time for stack depth d (3 layers here, but 50+ in frameworks). It does not depend on checked/unchecked. If traces are not needed, override `fillInStackTrace()` or use the 4-argument constructor with `writableStackTrace=false` to make creation O(1).
- **Space:** each exception stores its stack trace – O(d) memory. Chaining adds only one reference per link, but the cause keeps its own full trace alive, so a chain of k exceptions holds O(k·d) memory until the outermost exception is garbage collected.
