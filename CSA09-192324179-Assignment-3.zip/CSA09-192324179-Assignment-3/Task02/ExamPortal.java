import java.io.IOException;

/** Task 2 - Online Examination Portal: user-defined exceptions across controller / service / storage layers. */
public class ExamPortal {

    // ---------- Exception hierarchy ----------
    static class ExamException extends Exception {                       // CHECKED base
        ExamException(String m) { super(m); }
        ExamException(String m, Throwable c) { super(m, c); }
    }
    static class ExamClosedException extends ExamException {            // CHECKED
        ExamClosedException(String m) { super(m); }
    }
    static class NotRegisteredException extends ExamException {         // CHECKED
        NotRegisteredException(String m) { super(m); }
    }
    static class FileTooLargeException extends ExamException {          // CHECKED
        FileTooLargeException(String m) { super(m); }
    }
    static class SubmissionStorageException extends ExamException {     // CHECKED, carries cause
        SubmissionStorageException(String m, Throwable c) { super(m, c); }
    }
    static class PortalConfigException extends RuntimeException {       // UNCHECKED (programming/config error)
        PortalConfigException(String m) { super(m); }
    }

    // ---------- Storage layer ----------
    static class StorageLayer {
        void store(String student, String file, long sizeKb, boolean diskFull) throws SubmissionStorageException {
            try {
                if (diskFull) throw new IOException("No space left on device");
                System.out.println("  [storage] stored " + file + " for " + student);
            } catch (IOException e) {
                throw new SubmissionStorageException("Could not store " + file, e);   // chained
            }
        }
    }

    // ---------- Service layer ----------
    static class SubmissionService {
        private final StorageLayer storage = new StorageLayer();
        void submit(String student, String course, String file, long sizeKb, boolean windowOpen,
                    boolean registered, boolean diskFull) throws ExamException {
            if (file == null) throw new PortalConfigException("file name is null");
            if (!windowOpen)  throw new ExamClosedException("Exam window closed for " + course);
            if (!registered)  throw new NotRegisteredException(student + " is not registered for " + course);
            if (sizeKb > 500) throw new FileTooLargeException(file + " is " + sizeKb + " KB (limit 500 KB)");
            storage.store(student, file, sizeKb, diskFull);          // throws propagate upwards
        }
    }

    // ---------- Controller layer (final handling) ----------
    static class Controller {
        private final SubmissionService service = new SubmissionService();
        void handle(String label, String student, String course, String file, long kb,
                    boolean open, boolean reg, boolean disk) {
            System.out.println("Scenario: " + label);
            try {
                service.submit(student, course, file, kb, open, reg, disk);
                System.out.println("  Student sees: Submission successful");
            } catch (ExamClosedException | NotRegisteredException | FileTooLargeException e) {
                System.out.println("  Student sees: " + e.getMessage());
            } catch (SubmissionStorageException e) {
                System.out.println("  Student sees: Sorry, we could not save your answer. Try again.");
                System.out.println("  Log -> message : " + e.getMessage());
                System.out.println("  Log -> getCause: " + e.getCause());
                e.printStackTrace(System.out);                   // full chained trace ("Caused by: ...")
            } catch (ExamException e) {
                System.out.println("  Student sees: Unexpected exam error: " + e.getMessage());
            }
            System.out.println();
        }
    }

    // ---------- Re-throw WITHOUT cause: information lost ----------
    static void lossyRethrow() {
        System.out.println("Scenario: re-throw without cause");
        try {
            try {
                throw new IOException("No space left on device");
            } catch (IOException e) {
                throw new SubmissionStorageException("Could not store answer.pdf", null);   // cause dropped!
            }
        } catch (SubmissionStorageException e) {
            System.out.println("  getCause() = " + e.getCause() + "   <-- original IOException lost");
            e.printStackTrace(System.out);
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Controller c = new Controller();
        c.handle("S1 valid",              "Asha", "CSA09", "answer.pdf", 120, true,  true,  false);
        c.handle("S2 window closed",      "Asha", "CSA09", "answer.pdf", 120, false, true,  false);
        c.handle("S3 not registered",     "Ravi", "CSA09", "answer.pdf", 120, true,  false, false);
        c.handle("S4 file too large",     "Asha", "CSA09", "big.pdf",    900, true,  true,  false);
        c.handle("S5 storage failure",    "Asha", "CSA09", "answer.pdf", 120, true,  true,  true);
        lossyRethrow();
        try {
            new SubmissionService().submit("Asha", "CSA09", null, 1, true, true, false);
        } catch (PortalConfigException e) {
            System.out.println("Unchecked PortalConfigException (no throws clause needed): " + e.getMessage());
        } catch (ExamException e) { /* not reached */ }
    }
}
