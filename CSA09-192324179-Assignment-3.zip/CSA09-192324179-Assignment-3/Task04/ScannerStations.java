import java.util.concurrent.atomic.AtomicInteger;

/** Task 4 - Four scanner stations: Thread vs Runnable, start/run, join, priorities, daemon. */
public class ScannerStations {

    static final int[] scanned = new int[4];

    static void scanWork(int station, int scripts) {
        for (int i = 1; i <= scripts; i++) {
            try { Thread.sleep((long) (Math.random() * 50)); } catch (InterruptedException e) { return; }
            scanned[station]++;
        }
        System.out.println(Thread.currentThread().getName() + " finished: " + scanned[station] + " scripts");
    }

    static class StationThread extends Thread {           // way 1: extend Thread
        final int id, scripts;
        StationThread(int id, int scripts) { super("Station-" + id); this.id = id; this.scripts = scripts; }
        @Override public void run() { scanWork(id, scripts); }
    }

    static class StationTask implements Runnable {         // way 2: implement Runnable
        final int id, scripts;
        StationTask(int id, int scripts) { this.id = id; this.scripts = scripts; }
        @Override public void run() { scanWork(id, scripts); }
    }

    static int total() { int t = 0; for (int s : scanned) t += s; return t; }

    public static void main(String[] args) throws InterruptedException {
        // ---- Part 1: extends Thread ----
        System.out.println("=== Part 1: extending Thread ===");
        java.util.Arrays.fill(scanned, 0);
        Thread[] ts = new Thread[4];
        for (int i = 0; i < 4; i++) { ts[i] = new StationThread(i, 10 + i * 5); }
        System.out.println("State before start: " + ts[0].getState());               // NEW
        for (Thread t : ts) t.start();
        System.out.println("isAlive right after start: " + ts[0].isAlive());
        Thread.sleep(20);
        System.out.println("State while sleeping/working: " + ts[0].getState());     // TIMED_WAITING
        for (Thread t : ts) t.join();                                                // wait for all
        System.out.println("State after join: " + ts[0].getState() + ", isAlive=" + ts[0].isAlive()); // TERMINATED
        System.out.println("TOTAL scanned (printed after join) = " + total());

        // ---- Part 2: implements Runnable ----
        System.out.println("\n=== Part 2: implementing Runnable ===");
        java.util.Arrays.fill(scanned, 0);
        Thread[] rs = new Thread[4];
        for (int i = 0; i < 4; i++) rs[i] = new Thread(new StationTask(i, 10 + i * 5), "Runnable-Station-" + i);
        for (Thread t : rs) t.start();
        for (Thread t : rs) t.join();
        System.out.println("TOTAL scanned = " + total());

        // ---- Part 3: run() vs start() ----
        System.out.println("\n=== Part 3: run() vs start() ===");
        Thread demo = new Thread(() -> System.out.println("  executing in thread: " + Thread.currentThread().getName()), "Worker-X");
        System.out.println("main calls run():");   demo.run();                // runs in MAIN
        Thread demo2 = new Thread(() -> System.out.println("  executing in thread: " + Thread.currentThread().getName()), "Worker-Y");
        System.out.println("main calls start():"); demo2.start(); demo2.join(); // runs in Worker-Y

        // ---- Part 4: priorities ----
        System.out.println("\n=== Part 4: priorities (finishing order may or may not change) ===");
        java.util.Arrays.fill(scanned, 0);
        Thread[] ps = new Thread[4];
        for (int i = 0; i < 4; i++) {
            ps[i] = new StationThread(i, 20);
            ps[i].setPriority(i == 0 ? Thread.MAX_PRIORITY : Thread.MIN_PRIORITY);
        }
        for (Thread t : ps) t.start();
        for (Thread t : ps) t.join();

        // ---- Part 5: daemon ----
        System.out.println("\n=== Part 5: daemon thread ===");
        Thread daemon = new StationThread(3, 1000);      // would need ~25 s
        daemon.setDaemon(true);
        daemon.start();
        Thread.sleep(200);
        System.out.println("main() ends now; the daemon station is still scanning -> JVM exits, daemon killed.");
    }
}
