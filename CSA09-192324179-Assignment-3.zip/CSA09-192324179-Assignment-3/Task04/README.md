# Task 4 – Thread Creation and the Thread Life Cycle (K4 – Analyse)

Files: `ScannerStations.java`, `ExecutorStations.java`, `OUTPUT.md`
Run: `cd Task04 && javac *.java && java ScannerStations` (run it **at least 10 times**) and `java ExecutorStations`
(`ExecutorStations` may print an "unchecked" compiler note – harmless.)
`ScannerStations` has 5 parts: (1) extends Thread, (2) implements Runnable, (3) run() vs start(), (4) priorities, (5) daemon thread.

## Shared Group Work
- Four stations (ids 0–3) with 10, 15, 20, 25 scripts. Uses `start()`, `sleep()` (simulated scanning time), `join()` (wait for all) and `isAlive()`.
- The finishing order differs from run to run (record it for each run).

## Student A – Thread Design

### Thread vs Runnable

| | `extends Thread` | `implements Runnable` |
|---|---|---|
| Inheritance | Uses up the single superclass slot | Class can still extend another class |
| Design | Task and thread mixed together | Task separated from the mechanism of running it |
| Reuse | One object = one thread | Same Runnable can be given to several threads or an executor |
| Preferred | Only when the thread's own behaviour is being changed | **Usually preferred** – works with `ExecutorService`, lambdas |

### Thread life-cycle
```
NEW ──start()──► RUNNABLE ◄──scheduler──► (running)
                    │  ▲
   sleep(ms)/join(ms)│  │time over
                    ▼  │
              TIMED_WAITING
   join()/wait()  ──► WAITING        lock busy ──► BLOCKED
                    │
              run() ends / exception
                    ▼
               TERMINATED
```
Each station passes through: **NEW** (object created, `getState()` printed before `start()`) → **RUNNABLE** (after `start()`) → **TIMED_WAITING** (inside `Thread.sleep`, printed after 20 ms) → RUNNABLE again (repeated for every script) → **TERMINATED** (after the last script; printed after `join()`). `main` is WAITING while it is inside `join()`.

### run() vs start()
Part 3 of the program prints the thread name: calling `run()` prints `main` – it is an ordinary method call executed by the **calling thread** (no new thread, no concurrency). Calling `start()` prints `Worker-Y` – the JVM creates a new thread, which then calls `run()`. (Also, `start()` can be called only once – a second call throws `IllegalThreadStateException`.)

### How join() gives a correct final total
`t.join()` makes the calling thread (main) wait until `t` is TERMINATED. After `join()` has been called on all four stations, every `scanned[i]` has its final value, so the total printed after the loop is complete. Without `join()`, main would print immediately while the stations were still scanning (the total would be too small); `join()` also gives a happens-before guarantee, so main sees the writes.

## Student B – Behavioural Experiments

### 10-run table (fill from your runs)

| Run | Finish order of Station-0,1,2,3 |
|---|---|
| 1 | |
| 2 | |
| … | |
| 10 | |

Expected observation: Station-0 (10 scripts) usually finishes first and Station-3 (25 scripts) last, but because each script takes a *random* 0–50 ms sleep the order is not identical every time.

### Priorities
Part 4 gives station 0 `MAX_PRIORITY` and the rest `MIN_PRIORITY`. Record the order in several runs. Expected: **no reliable change** – threads here mostly sleep, and priority is only a *hint* to the OS scheduler (on Linux/Windows it is often ignored for the Java thread library).

### Daemon thread
In Part 5 a station is made a daemon and given 1000 scripts (~25 s). `main()` ends after 200 ms and the JVM **exits immediately** – the station's "finished" line never appears. A JVM stops when only daemon threads remain; they are killed without finishing or running `finally`. Non-daemon (user) threads keep the JVM alive.

### Explanation using the scheduler
The OS scheduler decides which RUNNABLE thread gets the CPU and for how long; sleeping threads wake up at unpredictable times, so interleaving varies with load, core count and timing. Priorities only influence, never guarantee, this order.

## Joint Conclusion
The same program gives different orders because thread scheduling is non-deterministic (timeslices, number of cores, other processes, sleeping/wake-up times, I/O). A correct program must not depend on the order – results must be correct for *every* legal interleaving, which is achieved with `join()`, synchronisation and thread-safe collections instead of assumptions such as "Station 0 always finishes first" (that would be a race condition).

## Alternative Concept and Complexity Analysis – ExecutorService
```java
ExecutorService pool = Executors.newFixedThreadPool(p);       // p worker threads
Future<Integer> f = pool.submit(() -> scan(station));          // task, not thread
total += f.get();                                              // replaces join()
pool.shutdown();
```
(see `ExecutorStations.java`). The pool reuses `p` threads for all tasks, queues the extra tasks, and returns results through `Future`.

| | Own `Thread` objects (one per station/batch) | Fixed pool with `p` threads |
|---|---|---|
| Completion time for n scripts of cost t | ≈ (n/k)·t with k = number of threads started (all in parallel if enough cores) | ≈ ⌈n/p⌉·t (about n/p batches); queued tasks wait |
| Thread creation cost | O(number of threads) – new thread every time | O(p) once, reused for any number of tasks |
| Memory (thread stacks) | k × stack size (≈ 1 MB each on 64-bit Linux, default `-Xss`) – grows with the number of threads | p × stack size, fixed; plus a small queue object per waiting task |
| Failure handling / result | Manual (shared arrays + `join`) | `Future.get()` returns the result or throws `ExecutionException` |

With 4 stations and p = 4 both finish at the same time; with p = 2 the pool takes about twice as long but uses half the thread memory.
