import java.util.concurrent.*;

/** Task 4 alternative: same four stations with a fixed thread pool. */
public class ExecutorStations {
    public static void main(String[] args) throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(2);     // p = 2 threads for 4 stations
        Future<Integer>[] f = new Future[4];
        for (int i = 0; i < 4; i++) {
            final int id = i, scripts = 10 + i * 5;
            f[i] = pool.submit(() -> {
                for (int k = 0; k < scripts; k++) Thread.sleep((long) (Math.random() * 50));
                System.out.println(Thread.currentThread().getName() + " finished station " + id);
                return scripts;
            });
        }
        int total = 0;
        for (Future<Integer> x : f) total += x.get();               // get() = join + result
        pool.shutdown();
        System.out.println("TOTAL scanned = " + total);
    }
}
